# Databricks notebook source
# MAGIC %md
# MAGIC # Ingest Synthea Records
# MAGIC In this notebook we ingest synthetic patient records generated using [synthea](https://github.com/synthetichealth/synthea/wiki).
# MAGIC The raw data is in csv format. In this notebook, we ingest the data into the bronze layer.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Configuration

# COMMAND ----------

dbutils.widgets.text('storage_location','/Volumes/dataengineering/transformation/volumes_demo/')
dbutils.widgets.text('catalog_schema','dataengineering.transformation')

# COMMAND ----------

catalog_schema = f"{dbutils.widgets.get('catalog_schema')}".rstrip('.')
root_path = f"{dbutils.widgets.get('storage_location')}/synthea/health-lakehouse/".replace('//', '/')
synthea_path = f"{dbutils.widgets.get('storage_location')}/synthea/hls/synthea/data/".replace('//', '/')

# COMMAND ----------

print(f"catalog_schema is {catalog_schema}")
print(f"root_path is {root_path}")
print(f"synthea_path is {synthea_path}")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC First we specify paths to raw data and the root directory to delta tables.

# COMMAND ----------

delta_root_path = f"{root_path}delta/"
print(f'Delta Output Path:{delta_root_path}')

# COMMAND ----------

l = dbutils.fs.ls(synthea_path)

df = spark.createDataFrame(l)

display(df)

# COMMAND ----------

def extract_tar_gz_files(df,synthea_path):

  import tarfile
  import os

  from pyspark.sql.functions import col, expr

  # Assuming 'df' is a pre-existing Spark DataFrame and it has a column named 'path'
  # Filter rows where the path ends with '.tar.gz'
  tar_gz_df = df.filter(col("path").endswith('.tar.gz'))

  # Add a new column 'tar_path_name' by removing '.tar.gz' from the end of 'path'
  # Here we're using an SQL expression via expr() function for string manipulation
  tar_gz_df_with_name = tar_gz_df.withColumn("tar_path_name", expr("substring(path, 1, length(path)-7)"))

  #display(tar_gz_df_with_name)

  # Collects the distinct directory names as a list of rows
  tar_path_names = tar_gz_df_with_name.select("tar_path_name","path").distinct().collect()

  # Iterates over each row and creates directories accordingly
  # Check if the .tar.gz files exist before trying to open them
  for row in tar_path_names:
      tar_path_name = row["tar_path_name"]
      tar_path = row["path"]
      
      # Check if the .tar.gz file exists in DBFS
      if dbutils.fs.ls(tar_path):
          # Create directories using dbutils.fs.mkdirs
          dbutils.fs.mkdirs(tar_path_name)
          
          # Since we're using the tarfile.open method below we use "dbfs:/" instead of "/dbfs/"
          #adjusted_tar_path = '/dbfs' + tar_path.lstrip('dbfs:') #use this version when using a dbfs path not registered as a volume
          adjusted_tar_path = tar_path.lstrip('dbfs:') #use this version when using volumes
          
          # Open the .tar.gz file for reading (using adjusted path)
          with tarfile.open(adjusted_tar_path, "r:gz") as tar:
              # Extract all contents into the target directory (using adjusted path)
              #tar.extractall(path = '/dbfs' + tar_path_name.lstrip('dbfs:')) #use this version when using a dbfs path not registered as a volume
              tar.extractall(path = tar_path_name.lstrip('dbfs:')) #use this version when using volumes
          
          print(f"Contents extracted to {tar_path_name}")

          #uncomment below for validation
          #l2 = dbutils.fs.ls(tar_path_name)

          #df2 = spark.createDataFrame(l2)

          #display(df2)

# COMMAND ----------

extract_tar_gz_files(df,synthea_path)

# COMMAND ----------

l3 = dbutils.fs.ls(f"{synthea_path}/dbxsynthea/data/")

df3 = spark.createDataFrame(l3)

display(df3)

# COMMAND ----------

datasets= ['allergies',
          'careplans',
          'conditions',
          'devices',
          'encounters',
          'imaging_studies',
          'immunizations',
          'medications',
          'observations',
          'organizations',
          'patients',
          'payer_transitions',
          'payers',
          'procedures',
          'providers',
          'supplies'
         ]

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Ingest CSV files as spark dataframes
# MAGIC Next we ingest all these files into spark dataframes, and take a look at the number of records in each table. Note that here, for simplicity we recursivley read each table and store the collection of dataframes as a dictionary, which makes it easier to reference the dataframes when we write them to deltalake. As you notice, we specify `inferSchema=True`, which causes a scan of the rows to infer the schema. In practice, to make the ingest faster it is recommended to specify the schema explicitly.

# COMMAND ----------

# create a python dictionary of dataframes
df_dict = {}
for dataset in datasets:
    df_dict[dataset] = spark.read.csv('{}/dbxsynthea/data/*/csv/*/{}.csv'.format(synthea_path,dataset),header=True,inferSchema=True)

# COMMAND ----------

# MAGIC %md
# MAGIC Now let's take a look at the number of rows for each table.

# COMMAND ----------

import pandas as pd
dataframes=[(x[0],x[1].count()) for x in list(df_dict.items())]
display(pd.DataFrame(dataframes,columns=['dataset','n_records']).sort_values(by=['n_records'],ascending=False))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Write tables to Delta
# MAGIC Now we can write all the ingested tables into [delta lake](https://docs.databricks.com/delta/delta-intro.html#introduction)

# COMMAND ----------

try:
  dbutils.fs.ls(delta_root_path)
except:
  print(f'Path {delta_root_path} does not exist, creating path {delta_root_path}')
  dbutils.fs.mkdirs(delta_root_path)
print(f'Delta tables will be stored in {delta_root_path}')

# COMMAND ----------

for table_name in datasets:
  table_path = delta_root_path + '/bronze/{}'.format(table_name)
  df_dict[table_name].write.format('delta').mode("overwrite").save(table_path)

  # Command to create table
  spark.sql(f"""
  CREATE  TABLE IF NOT EXISTS {catalog_schema}.{table_name}
  select  * 
  from    delta.`{table_path}`
  ;
  """)


# COMMAND ----------

# MAGIC %md
# MAGIC Note that in the above command, we wrote the tables in `overwrite` mode. You can also change this to `append` if you are adding new batches of data to your delta lake. For more information see: [Table batch reads and writes](https://docs.databricks.com/delta/delta-batch.html#write-to-a-table) in databricks delta documentations.

# COMMAND ----------

# MAGIC %md
# MAGIC Copyright / License info of the notebook. Copyright Databricks, Inc. [2021].  The source in this notebook is provided subject to the [Databricks License](https://databricks.com/db-license-source).  All included or referenced third party libraries are subject to the licenses set forth below.
# MAGIC
# MAGIC |Library Name|Library License|Library License URL|Library Source URL| 
# MAGIC | :-: | :-:| :-: | :-:|
# MAGIC |Smolder |Apache-2.0 License| https://github.com/databrickslabs/smolder | https://github.com/databrickslabs/smolder/blob/master/LICENSE|
# MAGIC |Synthea|Apache License 2.0|https://github.com/synthetichealth/synthea/blob/master/LICENSE| https://github.com/synthetichealth/synthea|
# MAGIC | OHDSI/CommonDataModel| Apache License 2.0 | https://github.com/OHDSI/CommonDataModel/blob/master/LICENSE | https://github.com/OHDSI/CommonDataModel |
# MAGIC | OHDSI/ETL-Synthea| Apache License 2.0 | https://github.com/OHDSI/ETL-Synthea/blob/master/LICENSE | https://github.com/OHDSI/ETL-Synthea |
# MAGIC |OHDSI/OMOP-Queries|||https://github.com/OHDSI/OMOP-Queries|
# MAGIC |The Book of OHDSI | Creative Commons Zero v1.0 Universal license.|https://ohdsi.github.io/TheBookOfOhdsi/index.html#license|https://ohdsi.github.io/TheBookOfOhdsi/|